<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

?>
<style>
<?php include 'EP_CSS.css'; ?>
</style>

<p class="ft"> &copy WMU CIS 4990 ENTERPRISE PROJECT</p>
